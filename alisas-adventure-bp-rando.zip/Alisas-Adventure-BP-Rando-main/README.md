<h1>changelog</h1>
<h2>v0.1.0</h2>
<h3>2024.10.20</h3>
<ul>
    <li>Official release of application.</li>
</ul>
